import json

# Initializes the number of emailData objects to create
numOfObjects = 2


# Opens the template file
with open("SendEmailRequest.json", "r") as file:
    data = json.load(file)
    file.close()


# Acquires the emailData object to copy
emailDataList = data["emailData"]
copiedDict = emailDataList[0]


# Iterates over the number initialized
for i in range(numOfObjects):
    emailDataList.append(copiedDict)


# Updates the dictionary object with the new list
data.update({"emailData": emailDataList})


# Writes the result to a different json file
with open("SendEmailRequest_Final.json", "w") as file:
    json.dump(data, file)
    file.close()